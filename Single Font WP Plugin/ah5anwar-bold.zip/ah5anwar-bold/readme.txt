=== Creatives iT - AH5 Anwar V1 Bold - Font ===
Contributors: Anwar Hossain AH5
Donate link: https://creativesit.com/
Tags: bangla font,bangla font for wordpress
Requires at least: 5.2
Tested up to: 6.9
Version: 1.0
Stable tag: 2.2
Requires PHP: 5.6
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Make Bengali text on your website clear and beautiful, enhancing readability and giving your content a neat, polished look.

== Description ==

Bangla language people are regularly facing Bengali font problem in WordPress.

== Installation ==

1. Unpack the entire contents of this plugin zip file into your wp-content/plugins/ folder locally
2. Upload to your site
3. Navigate to wp-admin/plugins.php on your site (your WP Admin plugin page)
4. Activate this plugin

OR you can just install it with WordPress by going to Plugins > Add New > and type this plugin’s name

== Frequently Asked Questions ==

= Can i install this plugin any wordpres site ? =

Yes this plugin are compatible with any wordpress site

== Screenshots ==
1. Sample of font applied

== Upgrade Notice ==

Safe to upgrade

== Changelog ==

= 1.0.0 – Feb 02, 2026 =
* Initial release
<?php
/*
Plugin Name: AH5 Anwar V2 Bold
Plugin URI: http://creativesit.com
Description: Enables Creatives iT Web Fonts.
Author: Anwar Hossain AH5
Version: 1.0
Author URI: http://facebook.com/ah5anwar
*/

/*
Bangladesh;
*/

// Bismillah...

	defined( 'ABSPATH' ) or die( 'Stop! You can not do this!' );
	
	function embed_ah5anwarv2_bold_font() {
		print(
			'<link href="'.plugins_url( 'ah5anwarv2-bold/font.css', __FILE__ ).'" rel="stylesheet">'
		);
		
	?>
		<style>
		html, body, div, form span, applet, object, iframe, h1, h2, h3, h4, h5, h6, p, blockquote, pre, a,input, .topbar, .main-menu, .breadcrumb, .copyrights-area,.required, acronym, address, big, del, dfn, em, img, q, s, samp, small, strike, strong, sub, sup, tt, var, b, u, center, dl, dt, dd, ol, ul, li, fieldset, form, label, legend, table, caption, tbody, tfoot, thead, tr, th, td, article, aside, canvas, details, embed, figure, figcaption, footer, header, hgroup, menu, nav, output, ruby, section, summary, time, mark, audio, video, textarea, input, select
			{ font-family: 'ah5anwarv2-bold', Arial, sans-serif !important; }
		</style>
	<?php
	}
	
	add_action('wp_head', 'embed_ah5anwarv2_bold_font');
	
	?>

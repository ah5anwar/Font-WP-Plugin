<?php
/* AH5 Fonts Settings Page */

class ah5fonts_Settings_Page {
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'ah5f_create_settings' ) );
		add_action( 'admin_init', array( $this, 'ah5f_setup_sections' ) );
		add_action( 'admin_init', array( $this, 'ah5f_setup_fields' ) );
	}
	public function ah5f_create_settings() {
		$page_title = __('AH5 Fonts Collection', 'ah5fontscol');
		$menu_title = __('AH5 Fonts', 'ah5fontscol');
		$capability = 'manage_options';
		$slug = 'ah5fonts';
        $callback = array($this, 'ah5f_settings_content');
        $icon = 'dashicons-translation';
		$position = 60;
		add_menu_page($page_title, $menu_title, $capability, $slug, $callback, $icon, $position);
	
	}
	public function ah5f_settings_content() { ?>
		<div class="wrap">
			<h1><?php _e('AH5 Fonts Collection','ah5fontscol') ?></h1>
			<?php settings_errors(); ?>
			<form method="POST" action="options.php">
				<?php
					settings_fields( 'ah5fonts' );
					do_settings_sections( 'ah5fonts' );
					submit_button();
				?>
			</form>
			<div class="samplecode">
			<h4><?php _e('Sample CSS selector to set font','ah5fontscol') ?></h4>
			<code>
			html, body, div, form span, applet, object, iframe, h1, h2, h3, h4, h5, h6, p, blockquote, pre, a,input, .topbar, .main-menu, .breadcrumb, .copyrights-area,.required, acronym, address, big, del, dfn, em, img, q, s, samp, small, strike, strong, sub, sup, tt, var, b, u, center, dl, dt, dd, ol, ul, li, fieldset, form, label, legend, table, caption, tbody, tfoot, thead, tr, th, td, article, aside, canvas, details, embed, figure, figcaption, footer, header, hgroup, menu, nav, output, ruby, section, summary, time, mark, audio, video, textarea, input, select
			{ font-family: 'AH5Anwarv2-Bold', Arial, sans-serif !important; }
			</code>
			</div>
			<div class="fontlist">
			<h4><?php _e('Useable fonts list','ah5fontscol') ?></h4>
			<dl>

				<dt><?php _e('ah5anwar-regular','ah5fontscol')?></dt>
				<dd><code>font-family: ah5anwar-regular, arial, sans-serif !important;</code></dd>
				<dt><?php _e('ah5anwar-bold','ah5fontscol')?></dt>
				<dd><code>font-family: ah5anwar-bold, arial, sans-serif !important;</code></dd>
				<dt><?php _e('ah5anwarv2-bold','ah5fontscol')?></dt>
				<dd><code>font-family: ah5anwarv2-bold, arial, sans-serif !important;</code></dd>
				<dt><?php _e('ah5anwarv2-light','ah5fontscol')?></dt>
				<dd><code>font-family: ah5anwarv2-light, arial, sans-serif !important;</code></dd>
				<dt><?php _e('ah5anwarv2-regular','ah5fontscol')?></dt>
				<dd><code>font-family: ah5anwarv2-regular, arial, sans-serif !important;</code></dd>
				
			</dl>
			</div>
		</div>
	
	<?php
	}
	public function ah5f_setup_sections() {
		add_settings_section( 'ah5fonts_section', __('AH5 Fonts Settings', 'ah5fontscol'), array(), 'ah5fonts' );
	}
	public function ah5f_setup_fields() {
		$fields = array(
			array(
				'label' => __('CSS for your fonts', 'ah5fontscol'),
				'id' => 'ah5fontselectors',
				'type' => 'textarea',
				'section' => 'ah5fonts_section',
			),
		);
		foreach( $fields as $field ){
			add_settings_field( $field['id'], $field['label'], array( $this, 'ah5f_field_callback' ), 'ah5fonts', $field['section'], $field );
			register_setting( 'ah5fonts', $field['id'] );
		}
	}
	public function ah5f_field_callback( $field ) {
		$value = get_option( $field['id'] );
		switch ( $field['type'] ) {
				case 'textarea':
				printf( '<textarea name="%1$s" id="%1$s" placeholder="%2$s" rows="5" cols="50">%3$s</textarea>',
					$field['id'],
					isset($field['placeholder']) ? $field['placeholder'] : '',
					$value
					);
					break;
			default:
				printf( '<input name="%1$s" id="%1$s" type="%2$s" placeholder="%3$s" value="%4$s" />',
					$field['id'],
					$field['type'],
					isset($field['placeholder']) ? $field['placeholder'] : '',
					$value
				);
		}
		if( $desc = isset($field['desc']) ? $field['desc'] : ''  ) {
			printf( '<p class="description">%s </p>', $desc );
		}
	}
}
new ah5fonts_Settings_Page();
<?php
/*
Plugin Name:  AH5 Fonts Collection
Plugin URI:   http://creativesit.com/
Description:  AH5 fonts in your WordPress website
Version:      3.0
Author:       Anwar Hossain
Author URI:   http://anwar.com.bd
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  AH5 Font
Domain Path:  /languages
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/*
* Loading textdomain
*/
function ah5fontscol_load_textdomain() {
    load_plugin_textdomain('ah5fontscol', FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
}
add_action( 'plugins_loaded', 'ah5fontscol_load_textdomain' );

/*
* Adding Assets
*/
function ah5fontscol_add_fonts(){
    wp_enqueue_style( "ah5-fonts-css",  plugins_url( 'assets/ah5-fonts.css', __FILE__ ), null, '1.0' );
    wp_enqueue_style( "ah5-fonts-custom-css",  plugins_url( 'assets/ah5-fonts-custom.css', __FILE__ ), null, '1.0' );
}
add_action('wp_enqueue_scripts', 'ah5fontscol_add_fonts');

/*
* Adding Admin Assets
*/
function ah5fontscol_admin_assets($screen){
    $varr = time();
    wp_enqueue_script('avro-js', plugin_dir_url(__FILE__). '/assets/js/avro-v1.1.4.min.js', array('jquery'), '1.1.4', true);
    wp_enqueue_script('ah5fontscol-admin-js', plugin_dir_url(__FILE__). '/assets/js/ah5f-admin-script.js', array('avro-js'), $varr, true);
    wp_enqueue_style('ah5f-admin-style', plugin_dir_url(__FILE__). '/assets/css/ah5f-admin-style.css', false, $varr);
}
add_action('admin_enqueue_scripts', 'ah5fontscol_admin_assets');
/*
* Adding Setting Page
*/
require_once plugin_dir_path(__FILE__)."includes/settings.php";
// Setting link creation for setting page
function ah5fontscol_settings_link($links){
    $newlink = sprintf("<a href= '%s'>%s</a>", 'admin.php?page=ah5fonts', __('Settings', 'ah5fontscol'));
    $links[] = $newlink;
    return $links;
}
add_filter( 'plugin_action_links_'.plugin_basename(__FILE__), 'ah5fontscol_settings_link'); 

/*
* Adding Custom CSS of user to the head
*/
function ah5fontscol_fontface_css(){
    $ah5f_style = get_option('ah5fontselectors');
    wp_add_inline_style('ah5-fonts-custom-css', $ah5f_style );
}
add_action('wp_enqueue_scripts', 'ah5fontscol_fontface_css');

/*
* Adding Button to Admin Ban
*/
function ah5fontscol_admin_button($wp_admin_bar){
$args = array(
    'id' => 'ah5f-language-changer',
    'title' => 'English Enabled',
    'href' => '#',
    'meta' => array(
        'class' => 'ah5f-changer-button',
    )
);
$wp_admin_bar->add_node($args);
}

add_action('admin_bar_menu', 'ah5fontscol_admin_button', 999);
<?php
/**
 * Plugin Name: Creatives iT Fonts 2
 * Description: Set Your Creatives iT Fonts to your WordPress Website.
 * Plugin URI: https://creativesit.com/plugin/Creatives-iT-Fonts
 * Author: Anwar Hossain
 * Author URI: https://anwar.com.bd/
 * Version: 2.0.0
 * License: GPL2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: Creatives-iT-Fonts
 */



	defined( 'ABSPATH' ) or die( 'Stop! You can not do this!' );


	
	function CreativesiTFonts() {
		   $creativesit_fonts_settings_options = get_option( 'creativesit_fonts_settings_option_name' );
         $font_name = $creativesit_fonts_settings_options['select_font_0'];
         $font_name = str_replace(' ', '', $font_name);
         $font_css = plugins_url( 'font/'.$font_name.'/font.css', __FILE__ );
          wp_enqueue_style( 'creativesit-font', $font_css, [], time(), 'all' );
          

          }
		


	add_action('wp_enqueue_scripts', 'CreativesiTFonts');




class CreativesitFontSettings {
	private $creativesit_fonts_settings_options;

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'creativesit_fonts_settings_add_plugin_page' ) );
		add_action( 'admin_init', array( $this, 'creativesit_fonts_settings_page_init' ) );
	}

	public function creativesit_fonts_settings_add_plugin_page() {
		add_menu_page(
			'Creatives iT Fonts 2', // page_title
			'Creatives iT Fonts 2', // menu_title
			'manage_options', // capability
			'creativesit-font-settings', // menu_slug
			array( $this, 'creativesit_fonts_settings_create_admin_page' ), // function
			'dashicons-admin-generic', // icon_url
			65 // position
		);
	}

	public function creativesit_fonts_settings_create_admin_page() {
		$this->creativesit_fonts_settings_options = get_option( 'creativesit_fonts_settings_option_name' ); ?>

		<div class="wrap">
			<h2>Creatives iT Fonts</h2>
			<p>Select Your desired Creatives iT Fonts</p>
			<?php settings_errors(); ?>

			<form method="post" action="options.php">
				<?php
					settings_fields( 'creativesit_fonts_settings_option_group' );
					do_settings_sections( 'creativesit-font-settings-admin' );
					submit_button();
				?>
			</form>
		</div>
	<?php }

	public function creativesit_fonts_settings_page_init() {
		register_setting(
			'creativesit_fonts_settings_option_group', // option_group
			'creativesit_fonts_settings_option_name', // option_name
			array( $this, 'creativesit_fonts_settings_sanitize' ) // sanitize_callback
		);

		add_settings_section(
			'creativesit_fonts_settings_setting_section', // id
			'Settings', // title
			array( $this, 'creativesit_fonts_settings_section_info' ), // callback
			'creativesit-font-settings-admin' // page
		);

		add_settings_field(
			'select_font_0', // id
			'Select Font', // title
			array( $this, 'select_font_0_callback' ), // callback
			'creativesit-font-settings-admin', // page
			'creativesit_fonts_settings_setting_section' // section
		);
	}

	public function creativesit_fonts_settings_sanitize($input) {
		$sanitary_values = array();
		if ( isset( $input['select_font_0'] ) ) {
			$sanitary_values['select_font_0'] = $input['select_font_0'];
		}

		return $sanitary_values;
	}

	public function creativesit_fonts_settings_section_info() {
		
	}

	public function select_font_0_callback() {
		
		?> <select name="creativesit_fonts_settings_option_name[select_font_0]" id="select_font_0">
		
			<?php $selected = (isset( $this->creativesit_fonts_settings_options['select_font_0'] ) && $this->creativesit_fonts_settings_options['select_font_0'] === 'ah5anwar-regular ') ? 'selected' : '' ; ?>
			<option value="ah5anwar-regular " <?php echo $selected; ?>> AH5 Anwar v1 Regular</option>

			<?php $selected = (isset( $this->creativesit_fonts_settings_options['select_font_0'] ) && $this->creativesit_fonts_settings_options['select_font_0'] === 'ah5anwar-bold ') ? 'selected' : '' ; ?>
			<option value="ah5anwar-bold " <?php echo $selected; ?>> AH5 Anwar v1 Bold</option>

			<?php $selected = (isset( $this->creativesit_fonts_settings_options['select_font_0'] ) && $this->creativesit_fonts_settings_options['select_font_0'] === 'ah5anwarv2-regular ') ? 'selected' : '' ; ?>
			<option value="ah5anwarv2-regular " <?php echo $selected; ?>> AH5 Anwar v2 Regular</option>

			<?php $selected = (isset( $this->creativesit_fonts_settings_options['select_font_0'] ) && $this->creativesit_fonts_settings_options['select_font_0'] === 'ah5anwarv2-light ') ? 'selected' : '' ; ?>
			<option value="ah5anwarv2-light " <?php echo $selected; ?>> AH5 Anwar v2 Light</option>

			<?php $selected = (isset( $this->creativesit_fonts_settings_options['select_font_0'] ) && $this->creativesit_fonts_settings_options['select_font_0'] === 'ah5anwarv2-bold ') ? 'selected' : '' ; ?>
			<option value="ah5anwarv2-bold " <?php echo $selected; ?>> AH5 Anwar v2 Bold</option>

		</select> <?php
	}

}


if ( is_admin() )
	$creativesit_fonts_settings = new CreativesitFontSettings();


 function CreativesitFontFamily(){
 	$creativesit_fonts_settings_options = get_option( 'creativesit_fonts_settings_option_name' );
    $font_name = $creativesit_fonts_settings_options['select_font_0'];
    $font_name = str_replace('-', ' ', $font_name);
    $font_name = ucwords($font_name);
    $font_name = str_replace(' ', '', $font_name);

    return $font_name;



 }

	function embed_Creatives_it_Font() {

		
	?>
		<style>
			html, body, div, form span, applet, object, iframe, h1, h2, h3, h4, h5, h6, p, blockquote, pre, a,input, .topbar, .main-menu, .breadcrumb, .copyrights-area,.required,.primary-menu .common-menu-wrap .nav>li>a, form span.required, acronym, address, big, del, dfn, em, img, q, s, samp, small, strike, strong, sub, sup, tt, var, b, u, center, dl, dt, dd, ol, ul, li, fieldset, form, label, legend, table, caption, tbody, tfoot, thead, tr, th, td, article, aside, canvas, details, embed, figure, figcaption, footer, header, hgroup, menu, nav, output, ruby, section, summary, time, mark, audio, video, textarea, input, select
			
			{
				font-family: '<?php echo esc_html(CreativesitFontFamily()); ?>', sans-serif!important;

			}
		</style>
	<?php
	}
	
	
	add_action('wp_head', 'embed_Creatives_it_Font');
=== Creatives iT Fonts ===
Contributors: Creatives iT
Tags: bangla,font,news,Bangla Blog, Bangla  Font
Requires at least: 5.1
Tested up to: 6.0.2
Stable tag: 1.0.0
Requires PHP: 7.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Set Your Creatives iT Fonts to your WordPress Website.

== Description ==

This is a free Plugin for the Bangla website/blog. You can change the font of your WordPress website easily.
Available Bangla font is listed Below.


== Installation ==

1. Download The Plugin
2. Upload the plugin files to the `/wp-content/plugins/Creatives-iT-Fonts` directory, or install the plugin through the WordPress plugins screen directly.

3. Activate the plugin through the 'Plugins' screen in WordPress.
4. Use the Bangla Font Settings Option to configure the plugin.


== Frequently Asked Questions ==

= Is this plugin will work with any Theme  =

Yes, You can use this plugin with any WordPress theme.


== Screenshots ==

1. Set Font from Admin Panel.

== Changelog ==


== Upgrade Notice ==

=== Creatives iT Fonts ===
Contributors: Creatives iT
Tags: bangla, fonts, typography, bengali
Requires at least: 5.0
Tested up to: 6.8
Stable tag: 1.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A powerful and easy-to-use plugin to use 10+ beautiful Bangla fonts on website with live preview, fallback font options, and advanced typography.

== Description ==

Creatives iT Fonts is a user-friendly WordPress plugin that allows you to enhance your website with beautiful Bangla (Bengali) fonts.

**Key Features**:

- Choose from 12 Bangla fonts with a live preview.
- Set fallback fonts for compatibility.
- Adjust typography settings (font size, line height, letter spacing) with real-time preview.
- Option to override theme font size or use theme settings.
- Reset all settings to defaults with a single click.
- Dedicated disclaimer page outlining font licensing responsibilities.
- Modern, accessible admin interface with card-based design.

**Important Note:** Each font included in this plugin is bundled locally and has its own license (e.g., SIL Open Font License, GNU GPL, or others). Some fonts are free for personal and commercial use, while others may have restrictions. You are responsible for verifying the license of each font before using it in commercial projects. Review the Disclaimer page in the plugin settings and the `fonts/LICENSE.txt` file for more details.

== Installation ==

1. **Install the Plugin:**

   - Download the plugin ZIP file.
   - In your WordPress admin dashboard, go to Plugins > Add New > Upload Plugin.
   - Upload the ZIP file and click "Install Now."
   - Alternatively, install directly from the WordPress.org repository (once approved).

2. **Activate the Plugin:**

   - Go to Plugins and activate "Creatives iT Fonts."

3. **Configure Settings:**

   - Navigate to Settings > Creatives iT Fonts in the WordPress admin dashboard.
   - Select a Bangla font from the dropdown (e.g., Noto Serif Bengali).
   - Set fallback fonts (e.g., Arial, sans-serif).
   - Adjust typography settings (font size, line height, letter spacing).
   - Check "Override Theme Font Size" if you want the plugin’s font size to take precedence.
   - Save changes.

4. **Review the Disclaimer:**

   - Go to Settings > Creatives iT Fonts > Disclaimer to understand your responsibilities regarding font licensing.

5. **Test Your Website:**

   - Visit your website to ensure the selected font and typography settings are applied.
   - If the font doesn’t appear, check for theme CSS conflicts and adjust settings as needed.

== Frequently Asked Questions ==

= Can I use these fonts for commercial projects? =
Each font has its own license (e.g., SIL OFL, GNU GPL), included in the `fonts/LICENSE.txt` file. Some are free for commercial use, while others may have restrictions. You must verify the license for each font with its provider before using it in commercial projects. Refer to the Disclaimer page in the plugin settings for more information.

= Why isn’t the font appearing on my website? =
This may be due to CSS conflicts with your theme. Ensure the "Override Theme Font Size" option is checked if you want the plugin’s settings to take precedence. You may also need to increase CSS specificity in the plugin’s code or consult your theme’s documentation.

= Can I use both the plugin and my theme’s font size settings? =
Yes! By default, the plugin does not override your theme’s font size. Check the "Override Theme Font Size" option in the Typography Settings to use the plugin’s font size instead.

= How do I reset the settings? =
Go to Settings > Creatives iT Fonts and click the "Reset to Defaults" button. Confirm the prompt to restore default settings (Noto Serif Bengali, sans-serif fallback, 16px font size, 1.5 line height, 0px letter spacing).

= Is the plugin accessible? =
Yes, the plugin includes ARIA labels, sufficient color contrast, and keyboard navigation support to ensure accessibility for all users.

== Screenshots ==

1. **Settings Page**: A modern interface to select Bangla fonts, set fallback fonts, and adjust typography settings with a live preview.
2. **Font Preview**: Real-time preview of the selected font and typography settings applied to Bangla text.
3. **Disclaimer Page**: Detailed information about font licensing and user responsibilities.

== Changelog ==

= 1.0 =
- Initial release with 11 Bangla fonts (Adorsho Lipi, Apona Lohit, Baloo Da 2, Bangla, Ekushey Lohit, Kalpurush, Mukti, Noto Serif Bengali, Siyam Rupali, SolaimanLipi, Tiro Bangla).
- Features live font preview, fallback font options, typography settings (font size, line height, letter spacing), and override theme font size option.
- Includes modern card-based admin interface with accessibility features (ARIA labels, keyboard navigation).
- Provides font licensing information via `fonts/LICENSE.txt` and a dedicated disclaimer page.

== Upgrade Notice ==

= 1.0 =
Initial release of Creatives iT Fonts, providing 11 Bangla fonts with live preview, typography settings, and licensing information. Install to enhance your website with beautiful Bangla typography.

== Disclaimer ==

The Creatives iT Fonts plugin includes Bangla fonts from various providers, bundled locally within the plugin. Each font has its own license (e.g., SIL Open Font License, GNU GPL), included in the `fonts/LICENSE.txt` file. Users are responsible for verifying the license of each font before using it in commercial projects. The plugin author and BytesVibe are not liable for any legal or financial consequences arising from font misuse. Review the Disclaimer page in the plugin settings for full details.
jQuery(document).ready(function($) {
    var $fontSelect = $('#creativesit-font-select');
    var $fontSize = $('#creativesit-font-size');
    var $lineHeight = $('#creativesit-line-height');
    var $letterSpacing = $('#creativesit-letter-spacing');
    var $previewText = $('#font-preview p');

    // Load initial font and typography
    loadFont($fontSelect.val());
    updateTypography();

    // Update preview on font change
    $fontSelect.on('change', function() {
        loadFont($(this).val());
    });

    // Update preview on typography changes
    $fontSize.on('input', updateTypography);
    $lineHeight.on('input', updateTypography);
    $letterSpacing.on('input', updateTypography);

    // Handle notice dismissal
    $(document).on('click', '#creativesit-font-notice .notice-dismiss', function() {
        $.ajax({
            url: bangfocdData.ajaxurl,
            method: 'POST',
            data: {
                action: 'creativesit_font_cdn_dismiss_notice',
                _wpnonce: bangfocdData.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#creativesit-font-notice').slideUp(300, function() {
                        $(this).remove();
                    });
                }
            }
        });
    });

    function loadFont(fontKey) {
        var fontData = bangfocdData.fonts[fontKey];
        if (!fontData) return;

        // Remove existing font styles
        $('link[data-creativesit-font]').remove();

        // Add new font stylesheet
        $('<link>', {
            rel: 'stylesheet',
            href: fontData.url,
            'data-creativesit-font': fontKey
        }).appendTo('head');

        // Update preview font
        $previewText.css('font-family', getFontName(fontKey));
    }

    function updateTypography() {
        $previewText.css({
            'font-size': $fontSize.val() + 'px',
            'line-height': $lineHeight.val(),
            'letter-spacing': $letterSpacing.val() + 'px'
        });
    }

    function getFontName(fontKey) {
        var names = {
            'ah5anwar-bold': 'AH5Anwar v1 Bold',
            'ah5anwar-regular': 'AH5Anwar v1 Regular',
            'ah5anwarv2-regular': 'AH5Anwar v2 Regular',
            'ah5anwarv2-light': 'AH5Anwar v2 Light',
            'ah5anwarv2-bold': 'AH5Anwar v2 Bold',
        };
        return names[fontKey] || 'sans-serif';
    }
});
<?php
/*
Plugin Name: Creatives iT Fonts
Description: Creatives iT Fonts.
Version: 1.0
Author: Anwar Hossain
Author URI: https://anwar.com.bd/
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: Creatives iT Fonts
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Initialize the Creatives iT Fonts plugin
 */
class creativesit_font {
    private $font_option_name = 'creativesit_font_font';
    private $fallback_option_name = 'creativesit_font_fallback';
    private $font_size_option_name = 'creativesit_font_font_size';
    private $line_height_option_name = 'creativesit_font_line_height';
    private $letter_spacing_option_name = 'creativesit_font_letter_spacing';
    private $override_font_size_option_name = 'creativesit_font_override_font_size';
    private $dismiss_notice_option_name = 'creativesit_font_dismiss_notice';

    public function __construct() {
        // Register hooks
        add_action('wp_enqueue_scripts', [$this, 'enqueue_creativesit_fonts']);
        add_action('admin_menu', [$this, 'add_admin_pages']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
        add_action('admin_post_creativesit_font_reset', [$this, 'handle_reset']);
    }

    /**
     * Enqueue the selected Creatives iT Fonts and typography settings on the frontend
     */
    public function enqueue_creativesit_fonts() {
        $selected_font = get_option($this->font_option_name, 'ah5anwarv2-regular');
        $fallback_fonts = get_option($this->fallback_option_name, 'sans-serif');
        $font_size = get_option($this->font_size_option_name, '16');
        $line_height = get_option($this->line_height_option_name, '1.5');
        $letter_spacing = get_option($this->letter_spacing_option_name, '0');
        $override_font_size = get_option($this->override_font_size_option_name, '0');

        // Define available fonts from local sources
        $fonts = [

            'ah5anwar-bold' => [
                'name' => 'AH5Anwar v1 Bold',
                'url'  => plugins_url('fonts/ah5anwar-bold/font.css', __FILE__),
            ],
            'ah5anwar-regular' => [
                'name' => 'AH5Anwar v1 Regular',
                'url'  => plugins_url('fonts/ah5anwar-regular/font.css', __FILE__),
            ],
            'ah5anwarv2-regular' => [
                'name' => 'AH5Anwar v2 Regular',
                'url'  => plugins_url('fonts/ah5anwarv2-regular/font.css', __FILE__),
            ],
            'ah5anwarv2-light' => [
                'name' => 'AH5Anwar v2 Light',
                'url'  => plugins_url('fonts/ah5anwarv2-light/font.css', __FILE__),
            ],
            'ah5anwarv2-bold' => [
                'name' => 'AH5Anwar v2 Bold',
                'url'  => plugins_url('fonts/ah5anwarv2-bold/font.css', __FILE__),
            ],
            
        ];

        // Enqueue the selected font
        if (isset($fonts[$selected_font])) {
            $font = $fonts[$selected_font];
            wp_enqueue_style('creativesit-font-' . $selected_font, $font['url'], [], '1.0');

            // Apply font and typography settings
            $custom_css = sprintf(
                "body, p, h1, h2, h3, h4, h5, h6, .entry-content { 
                    font-family: '%s', %s !important; 
                    line-height: %s; 
                    letter-spacing: %spx; 
                }",
                esc_html($font['name']),
                esc_html($fallback_fonts),
                floatval($line_height),
                floatval($letter_spacing)
            );
            if ($override_font_size) {
                $custom_css .= sprintf(
                    "body, p, h1, h2, h3, h4, h5, h6, .entry-content { 
                        font-size: %spx !important; 
                    }",
                    floatval($font_size)
                );
            }
            wp_add_inline_style('creativesit-font-' . $selected_font, $custom_css);
        }
    }

    /**
     * Add settings and disclaimer pages to the admin menu
     */
    public function add_admin_pages() {
        add_menu_page(
            esc_html__('Creatives iT Fonts', 'creativesit-font'),
            esc_html__('Creatives iT Fonts', 'creativesit-font'),
            'manage_options',
            'creativesit-font',
            [$this, 'render_settings_page'],
            'dashicons-editor-textcolor'
        );
        add_submenu_page(
            'creativesit-font',
            esc_html__('Settings', 'creativesit-font'),
            esc_html__('Settings', 'creativesit-font'),
            'manage_options',
            'creativesit-font',
            [$this, 'render_settings_page']
        );
        add_submenu_page(
            'creativesit-font',
            esc_html__('Disclaimer', 'creativesit-font'),
            esc_html__('Disclaimer', 'creativesit-font'),
            'manage_options',
            'creativesit-font-disclaimer',
            [$this, 'render_disclaimer_page']
        );
    }

    /**
     * Register settings
     */
    public function register_settings() {
        // Font selection
        register_setting('creativesit_font_options', $this->font_option_name, [
            'sanitize_callback' => [$this, 'sanitize_font_selection'],
            'default'           => 'noto-serif-bengali',
        ]);

        // Fallback fonts
        register_setting('creativesit_font_options', $this->fallback_option_name, [
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => 'sans-serif',
        ]);

        // Typography settings
        register_setting('creativesit_font_options', $this->font_size_option_name, [
            'sanitize_callback' => [$this, 'sanitize_positive_float'],
            'default'           => '16',
        ]);
        register_setting('creativesit_font_options', $this->line_height_option_name, [
            'sanitize_callback' => [$this, 'sanitize_positive_float'],
            'default'           => '1.5',
        ]);
        register_setting('creativesit_font_options', $this->letter_spacing_option_name, [
            'sanitize_callback' => [$this, 'sanitize_float'],
            'default'           => '0',
        ]);
        register_setting('creativesit_font_options', $this->override_font_size_option_name, [
            'sanitize_callback' => [$this, 'sanitize_checkbox'],
            'default'           => '0',
        ]);

        // Dismiss notice
        register_setting('creativesit_font_options', $this->dismiss_notice_option_name, [
            'sanitize_callback' => [$this, 'sanitize_checkbox'],
            'default'           => '0',
        ]);

        // Settings section
        add_settings_section(
            'creativesit_font_general',
            esc_html__('Creatives iT Fonts Settings', 'creativesit-font'),
            null,
            'creativesit-font'
        );

        // Fields
        add_settings_field(
            'creativesit_font_select',
            esc_html__('Select Creatives iT Fonts', 'creativesit-font'),
            [$this, 'font_select_field'],
            'creativesit-font',
            'creativesit_font_general'
        );
        add_settings_field(
            'creativesit_font_fallback',
            esc_html__('Fallback Fonts', 'creativesit-font'),
            [$this, 'fallback_fonts_field'],
            'creativesit-font',
            'creativesit_font_general'
        );
        add_settings_field(
            'creativesit_font_typography',
            esc_html__('Typography Settings', 'creativesit-font'),
            [$this, 'typography_settings_field'],
            'creativesit-font',
            'creativesit_font_general'
        );
    }

    /**
     * Sanitize font selection
     */
    public function sanitize_font_selection($input) {
        $valid_fonts = [
            'ah5anwar-bold', 'ah5anwar-regular', 'ah5anwarv2-regular', 'ah5anwarv2-light', 'ah5anwarv2-bold',
        ];
        return in_array($input, $valid_fonts) ? $input : 'ah5anwarv2-regular';
    }

    /**
     * Sanitize positive float
     */
    public function sanitize_positive_float($input) {
        $value = floatval($input);
        return $value > 0 ? $value : 1;
    }

    /**
     * Sanitize float (can be negative)
     */
    public function sanitize_float($input) {
        return floatval($input);
    }

    /**
     * Sanitize checkbox
     */
    public function sanitize_checkbox($input) {
        return $input === '1' ? '1' : '0';
    }

    /**
     * Render the font selection field
     */
    public function font_select_field() {
        $selected_font = get_option($this->font_option_name, 'ah5anwarv2-regular');
        $fonts = [
			'ah5anwar-bold' => 'AH5Anwar v1 Bold',
            'ah5anwar-regular' => 'AH5Anwar v1 Regular',
            'ah5anwarv2-regular' => 'AH5Anwar v2 Regular',
            'ah5anwarv2-light' => 'AH5Anwar v2 Light',
            'ah5anwarv2-bold' => 'AH5Anwar v2 Bold',
			 ];
        ?>
        <div class="creativesit-font-card">
            <select name="<?php echo esc_attr($this->font_option_name); ?>" id="creativesit-font-select" aria-label="<?php esc_html_e('Select Creatives iT Fonts', 'creativesit-font'); ?>">
                <?php foreach ($fonts as $value => $label) : ?>
                    <option value="<?php echo esc_attr($value); ?>" <?php selected($selected_font, $value); ?>>
                        <?php echo esc_html($label); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <p class="description"><?php esc_html_e('Choose a Creatives iT Fonts from various sources to apply to your website.', 'creativesit-font'); ?></p>
            <div id="font-preview">
                <h3><?php esc_html_e('Font Preview', 'creativesit-font'); ?></h3>
                <p>আমার সোনার বাংলা, আমি তোমায় ভালোবাসি।
চিরদিন তোমার আকাশ, তোমার বাতাস, আমার প্রাণে বাজায় বাঁশি৷
ও মা, ফাগুনে তোর আমের বনে ঘ্রাণে পাগল করে,
মরি হায়, হায় রে—
ও মা, অঘ্রাণে তোর ভরা ক্ষেতে আমি কী বোছি মধুর হাসি৷
</p>
            </div>
        </div>
        <?php
    }

    /**
     * Render the fallback fonts field
     */
    public function fallback_fonts_field() {
        $fallback_fonts = get_option($this->fallback_option_name, 'sans-serif');
        ?>
        <div class="creativesit-font-card">
            <input type="text" name="<?php echo esc_attr($this->fallback_option_name); ?>" value="<?php echo esc_attr($fallback_fonts); ?>" class="regular-text" aria-label="<?php esc_html_e('Fallback Fonts', 'creativesit-font'); ?>" />
            <p class="description"><?php esc_html_e('Enter fallback fonts (e.g., Arial, sans-serif) in case the selected font fails to load.', 'creativesit-font'); ?></p>
        </div>
        <?php
    }

    /**
     * Render the typography settings field
     */
    public function typography_settings_field() {
        $font_size = get_option($this->font_size_option_name, '16');
        $line_height = get_option($this->line_height_option_name, '1.5');
        $letter_spacing = get_option($this->letter_spacing_option_name, '0');
        $override_font_size = get_option($this->override_font_size_option_name, '0');
        ?>
        <div class="creativesit-font-card">
            <h3><?php esc_html_e('Typography Settings', 'creativesit-font'); ?></h3>
            <p>
                <label for="bangla-override-font-size">
                    <input type="checkbox" name="<?php echo esc_attr($this->override_font_size_option_name); ?>" id="bangla-override-font-size" value="1" <?php checked($override_font_size, '1'); ?> />
                    <?php esc_html_e('Override Theme Font Size', 'creativesit-font'); ?>
                </label>
                <span class="description"><?php esc_html_e('Check to use the plugin’s font size instead of the theme’s.', 'creativesit-font'); ?></span>
            </p>
            <p>
                <label for="creativesit-font-size"><?php esc_html_e('Font Size (px)', 'creativesit-font'); ?></label><br>
                <input type="number" name="<?php echo esc_attr($this->font_size_option_name); ?>" id="creativesit-font-size" value="<?php echo esc_attr($font_size); ?>" min="1" step="0.1" class="small-text" aria-label="<?php esc_html_e('Font Size', 'creativesit-font'); ?>" />
            </p>
            <p>
                <label for="bangla-line-height"><?php esc_html_e('Line Height', 'creativesit-font'); ?></label><br>
                <input type="number" name="<?php echo esc_attr($this->line_height_option_name); ?>" id="bangla-line-height" value="<?php echo esc_attr($line_height); ?>" min="0.1" step="0.1" class="small-text" aria-label="<?php esc_html_e('Line Height', 'creativesit-font'); ?>" />
            </p>
            <p>
                <label for="bangla-letter-spacing"><?php esc_html_e('Letter Spacing (px)', 'creativesit-font'); ?></label><br>
                <input type="number" name="<?php echo esc_attr($this->letter_spacing_option_name); ?>" id="bangla-letter-spacing" value="<?php echo esc_attr($letter_spacing); ?>" step="0.1" class="small-text" aria-label="<?php esc_html_e('Letter Spacing', 'creativesit-font'); ?>" />
            </p>
            <p class="description"><?php esc_html_e('Adjust typography settings for better readability.', 'creativesit-font'); ?></p>
        </div>
        <?php
    }

    /**
     * Render the settings page
     */
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $dismissed = get_option($this->dismiss_notice_option_name, '0');
        ?>
        <div class="wrap creativesit-font-wrap">
            <h1><?php esc_html_e('Creatives iT Fonts Settings', 'creativesit-font'); ?></h1>
            <?php if ($dismissed !== '1') : ?>
                <div class="notice notice-warning is-dismissible" id="creativesit-font-notice">
                    <p><strong><?php esc_html_e('Important Licensing Information', 'creativesit-font'); ?>:</strong> <?php esc_html_e('The Creatives iT Fontss provided by this plugin are sourced from various providers and included locally. Each font has its own license (e.g., SIL Open Font License, GNU GPL, or others). While many fonts are free for personal and commercial use, some may have restrictions for commercial projects. Before using any font in a commercial website, app, or product, please verify its license with the font provider or author. Failure to comply with licensing terms may result in legal issues. For commercial use, consider consulting a legal expert.', 'creativesit-font'); ?></p>
                </div>
            <?php endif; ?>
            <form method="post" action="options.php">
                <?php
                settings_fields('creativesit_font_options');
                do_settings_sections('creativesit-font');
                submit_button();
                ?>
            </form>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" onsubmit="return confirm('<?php echo esc_js(esc_html__('Are you sure you want to reset all settings to their defaults?', 'creativesit-font')); ?>');">
                <input type="hidden" name="action" value="creativesit_font_reset" />
                <?php wp_nonce_field('creativesit_font_reset_nonce'); ?>
                <button type="submit" class="button button-secondary"><?php esc_html_e('Reset to Defaults', 'creativesit-font'); ?></button>
            </form>
        </div>
        <?php
    }

    /**
     * Render the disclaimer page
     */
    public function render_disclaimer_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap creativesit-font-wrap">
            <h1><?php esc_html_e('Creatives iT Fonts Disclaimer', 'creativesit-font'); ?></h1>
            <div class="creativesit-font-card">
                <h2><?php esc_html_e('Disclaimer for Font Usage', 'creativesit-font'); ?></h2>
                <p><?php esc_html_e('The Creatives iT Fonts plugin provides access to a variety of Creatives iT Fontss sourced from various providers, included locally within the plugin.', 'creativesit-font'); ?></p>
                <p><?php esc_html_e('Each font included in this plugin is subject to its own licensing terms, which may include the SIL Open Font License (OFL), GNU General Public License (GPL), or other licenses. While many of these fonts are free for both personal and commercial use, some may have specific restrictions, particularly for commercial applications such as websites, applications, or printed materials.', 'creativesit-font'); ?></p>
                <p><?php esc_html_e('As the user of this plugin, you are solely responsible for ensuring that your use of these fonts complies with their respective licenses. This includes verifying whether a font is suitable for commercial use and obtaining any necessary permissions from the font author or provider. The plugin author, Riduan Chowdhury, and BytesVibe are not responsible for any legal or financial consequences arising from the misuse of these fonts.', 'creativesit-font'); ?></p>
                <p><?php esc_html_e('We strongly recommend that you review the license for each font before using it in a commercial project. If you are unsure about a font’s licensing terms, contact the font provider or consult a legal expert to ensure compliance.', 'creativesit-font'); ?></p>
                <p><?php esc_html_e('By using this plugin, you acknowledge and agree to these terms and assume full responsibility for complying with the font licenses.', 'creativesit-font'); ?></p>
            </div>
        </div>
        <?php
    }

    /**
     * Handle reset action
     */
    public function handle_reset() {
        if (!current_user_can('manage_options') || !check_admin_referer('creativesit_font_reset_nonce')) {
            wp_die(esc_html__('You do not have permission to perform this action.', 'creativesit-font'));
        }

        // Reset all options to defaults
        update_option($this->font_option_name, 'ah5anwarv2-regular');
        update_option($this->fallback_option_name, 'sans-serif');
        update_option($this->font_size_option_name, '16');
        update_option($this->line_height_option_name, '1.5');
        update_option($this->letter_spacing_option_name, '0');
        update_option($this->override_font_size_option_name, '0');
        update_option($this->dismiss_notice_option_name, '0');

        // Generate nonce for success redirect
        $success_nonce = wp_create_nonce('creativesit_font_reset_success');

        // Redirect back to settings page with a success message and nonce
        wp_redirect(add_query_arg([
            'page' => 'creativesit-font',
            'reset' => 'success',
            '_wpnonce' => $success_nonce
        ], admin_url('admin.php')));
        exit;
    }

    /**
     * Enqueue admin scripts and styles for the settings and disclaimer pages
     */
    public function enqueue_admin_scripts($hook) {
        if ($hook !== 'toplevel_page_creativesit-font' && $hook !== 'creativesit-font_page_creativesit-font-disclaimer') {
            return;
        }
        wp_enqueue_style('creativesit-font-admin', plugins_url('css/admin-style.css', __FILE__), [], '1.0');
        wp_enqueue_script('creativesit-font-admin', plugins_url('js/admin-script.js', __FILE__), ['jquery'], '1.0', true);

        // Pass font data to JavaScript
        $fonts = [
            'ah5anwar-bold' => ['url' => plugins_url('fonts/ah5anwar-bold/font.css', __FILE__)],
            'ah5anwar-regular' => ['url' => plugins_url('fonts/ah5anwar-regular/font.css', __FILE__)],
            'ah5anwarv2-regular' => ['url' => plugins_url('fonts/ah5anwarv2-regular/font.css', __FILE__)],
            'ah5anwarv2-light' => ['url' => plugins_url('fonts/ah5anwarv2-light/font.css', __FILE__)],
            'ah5anwarv2-bold' => ['url' => plugins_url('fonts/ah5anwarv2-bold/font.css', __FILE__)],
        ];
        wp_localize_script('creativesit-font-admin', 'bangfocdData', [
            'fonts' => $fonts,
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('creativesit_font_dismiss_nonce')
        ]);

        // Add inline script to show reset success message with nonce verification
    if (
    $hook === 'toplevel_page_creativesit-font' &&
    isset($_GET['reset']) && $_GET['reset'] === 'success' &&
    isset($_GET['_wpnonce']) &&
    wp_verify_nonce(
        sanitize_text_field(wp_unslash($_GET['_wpnonce'])),
        'creativesit_font_reset_success'
    )
) {
            wp_add_inline_script('creativesit-font-admin', 'jQuery(document).ready(function($) { $("<div class=\"notice notice-success is-dismissible\"><p>' . esc_js(esc_html__('Settings have been reset to defaults.', 'creativesit-font')) . '</p></div>").insertAfter(".creativesit-font-wrap h1"); });');
        }
    }
}

// Handle AJAX request for dismissing notice
add_action('wp_ajax_creativesit_font_dismiss_notice', function () {
    check_ajax_referer('creativesit_font_dismiss_nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }
    update_option('creativesit_font_dismiss_notice', '1');
    wp_send_json_success();
});

// Instantiate the plugin
new creativesit_font();
?>